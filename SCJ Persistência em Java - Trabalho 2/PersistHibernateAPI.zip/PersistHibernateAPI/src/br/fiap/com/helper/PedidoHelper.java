package br.fiap.com.helper;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;

import br.fiap.com.config.HibernateUtil;
import br.fiap.com.entity.Cliente;
import br.fiap.com.entity.Pedido;

public class PedidoHelper {

	Session session = null;
	Transaction transaction = null;

	public void encerrar(){
		session.close();
	}

	public String salvar(Pedido pedido){ 
		try{
			session = HibernateUtil.getSessionFactory().getCurrentSession(); 
			transaction = session.beginTransaction();
			session.save(pedido);
			transaction.commit();
			return "Pedido salvo"; 
		}catch(Exception e){
			return e.getMessage();
		} 
	}
	
	public String salvar(Cliente cliente){ 
		try{
			session = HibernateUtil.getSessionFactory().getCurrentSession(); 
			transaction = session.beginTransaction();
			session.save(cliente);
			transaction.commit();
			return "Cliente salvo"; 
		}catch(Exception e){
			return e.getMessage();
		} 
	}

	public String adicionarPedido(int idCliente, Pedido pedido){ 
		try {
			Cliente cliente = new Cliente();
			session = HibernateUtil.getSessionFactory().getCurrentSession(); 
			transaction = session.beginTransaction();
			session.load(cliente, idCliente);
			pedido.setCliente(cliente);
			cliente.getPedidos().add(pedido); 
			session.update(cliente);
			transaction.commit();

			return "Pedido adicionado";

		} catch(Exception e){ 
			return e.getMessage();
		} 
	}
	
	
	public Pedido getPedido(int idPedido){
		Pedido pedido = new Pedido();
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.load(pedido, idPedido);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pedido;
	} 

	@SuppressWarnings("unchecked")
	public List<Pedido> listarPedidos(){ 
		List<Pedido> pedidos = new ArrayList<>();
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			TypedQuery<Pedido> query = session.createQuery("from Pedido");
			pedidos = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pedidos;
	}
	
	public Cliente getCliente(int idCliente){
		Cliente cliente = new Cliente();
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.load(cliente, idCliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cliente;
	}
	
	@SuppressWarnings("unchecked")
	public List<Cliente> listarClientes(String nome){ 
		List<Cliente> clientes = new ArrayList<>();
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			TypedQuery<Cliente> query = session.createQuery("from Cliente where nome like :nome");
			query.setParameter("nome", "%" + nome + "%");
			clientes = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return clientes;
	}

}
