package br.fiap.com.programa;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import br.fiap.com.entity.Pedido;
import br.fiap.com.helper.PedidoHelper;
import br.fiap.com.entity.Cliente;

public class TestePedido {

	private static PedidoHelper helper = new PedidoHelper();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		incluirCliente();
		incluirPedidos();
		incluirClientecomPedidos();
		
		listarCliente();
		listarPedido();
		listarClientes();
		listarPedidos();
			
	}
	
	public static void incluirCliente() {
		Cliente cliente1 = new Cliente();
		cliente1.setNome("Adriano");
		cliente1.setEmail("adriano@mail.com");
		System.out.println(helper.salvar(cliente1));
		Cliente cliente2 = new Cliente();
		cliente2.setNome("Alberto");
		cliente2.setEmail("alberto@mail.com");
		System.out.println(helper.salvar(cliente2));	
	}
	
	public static void incluirPedidos() {
		Pedido pedido1 = new Pedido();
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date data;
		try {
			data = new Date(format.parse("30/11/2017").getTime());
			pedido1.setData(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pedido1.setDescricao("Pedido 1");
		pedido1.setValor(100.0);
		Pedido pedido2 = new Pedido();
		try {
			data = new Date(format.parse("01/12/2017").getTime());
			pedido2.setData(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pedido2.setDescricao("Pedido 2");
		pedido2.setValor(200.0);
		System.out.println(helper.adicionarPedido(1, pedido1));	
		System.out.println(helper.adicionarPedido(1, pedido2));		
	}

	
	public static void incluirClientecomPedidos() {
		Cliente cliente = new Cliente();
		cliente.setNome("Paulo");
		cliente.setEmail("paulo@mail.com");
		
		Pedido pedido3 = new Pedido();
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date data;
		try {
			data = new Date(format.parse("10/12/2017").getTime());
			pedido3.setData(data);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		pedido3.setDescricao("Pedido 3");
		pedido3.setValor(100.0);
		pedido3.setCliente(cliente);
		
		Pedido pedido4 = new Pedido();
		try {
			data = new Date(format.parse("15/12/2017").getTime());
			pedido4.setData(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pedido4.setDescricao("Pedido 4");
		pedido4.setValor(200.0);
		pedido4.setCliente(cliente);

		System.out.println(helper.salvar(cliente));
		System.out.println(helper.salvar(pedido3));
		System.out.println(helper.salvar(pedido4));
		
	}
	
	public static void listarCliente() {
		Cliente cliente = helper.getCliente(1);
		System.out.println("---Listar Cliente ---");
		System.out.println("Id Cliente: " + cliente.getId() + " Nome: " + cliente.getNome() + " Email: " + cliente.getEmail());
		List<Pedido> pedidos = cliente.getPedidos();
		for(Pedido pedido: pedidos) {
			System.out.println("---Listar Pedidos do Cliente ---");
			System.out.println("Id Pedido: " + pedido.getId() + " Data: " + pedido.getData() + " Descri��o: " + pedido.getDescricao() + " Valor: " + pedido.getValor());			
		}

	}
	
	public static void listarPedido() {
		Pedido pedido = helper.getPedido(4);
		System.out.println("---Listar Pedido ---");
		System.out.println("Id Pedido: " + pedido.getId() + " Data: " + pedido.getData() + " Descri��o: " + pedido.getDescricao() + " Valor: " + pedido.getValor());
	}
	
	public static void listarClientes() {
		List<Cliente> clientes = helper.listarClientes("A");
		for(Cliente cliente: clientes) {
			System.out.println("---Listar Clientes ---");
			System.out.println("Id Cliente: " + cliente.getId() + " Nome: " + cliente.getNome() + " Email: " + cliente.getEmail());
		}
		
	}
	
	public static void listarPedidos() {
		List<Pedido> pedidos = helper.listarPedidos();
		for(Pedido pedido: pedidos) {
			System.out.println("---Listar Pedidos ---");
			System.out.println("Id Pedido: " + pedido.getId() + " Data: " + pedido.getData() + " Descri��o: " + pedido.getDescricao() + " Valor: " + pedido.getValor());			
		}		
	}
}
