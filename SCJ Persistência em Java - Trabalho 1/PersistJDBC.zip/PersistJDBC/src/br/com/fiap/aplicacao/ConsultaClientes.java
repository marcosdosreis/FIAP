package br.com.fiap.aplicacao;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.dao.DaoFactory;
import br.com.fiap.dao.PedidoDAO;
import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Pedido;

public class ConsultaClientes {

	public static void main(String[] args) {
	
		try {
			
			System.out.println("Consultando Cliente ...");
			
			ClienteDAO clientes = DaoFactory.GetClienteDAO();
			PedidoDAO pedidos = DaoFactory.GetPedidoDAO();
		
			Cliente cliente = clientes.buscarCliente(2);
			
			System.out.println("Cliente "+cliente.getNome()+" "+cliente.getEmail());
			
			for (Pedido pedido : cliente.getPedidos()) {
				System.out.println(pedido.getDescricao()+" "+pedido.getValor()+" "+pedido.getData());
			}
			
			System.out.println("Consulta Cliente Finalizado!");
			System.out.println("Consultando Pedidos ...");
			for (Pedido pedido : pedidos.listarPedidos(2)) {
				System.out.println(pedido.getDescricao()+" "+pedido.getValor()+" "+pedido.getData());
			}
			System.out.println("Consulta Pedidos Finalizado!");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}