package br.com.fiap.aplicacao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.dao.DaoFactory;
import br.com.fiap.dao.PedidoDAO;
import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Pedido;



public class CadastroClientes {

	public static void main(String[] args) {

		try {
			
			System.out.println("Cadastrando Cliente ...");
			
			ClienteDAO clientes = DaoFactory.GetClienteDAO();
			PedidoDAO pedidos = DaoFactory.GetPedidoDAO();
			
			List<Pedido> pedidosCliente = new ArrayList<>();
			
			Cliente cliente = new Cliente("Jos�", "jose@fiap.com.br", pedidosCliente);
			clientes.inserirCliente(cliente);
			
			pedidosCliente.add(new Pedido(new Date(),"Grampos", 3600,cliente.getId()));
			pedidosCliente.add(new Pedido(new Date(),"Borrachas", 2570,cliente.getId()));
			
			for (Pedido pedido : pedidosCliente) {
				pedidos.inserirPedido(pedido);
			}
			
			System.out.println("Cadastro Cliente Finalizado!");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	

	}

}
