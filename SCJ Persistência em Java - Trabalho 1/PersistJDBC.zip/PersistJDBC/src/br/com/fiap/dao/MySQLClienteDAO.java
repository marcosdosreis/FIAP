package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Pedido;

public class MySQLClienteDAO implements ClienteDAO {
	Connection cn;
	PreparedStatement stmt;
	ResultSet rs;

	@Override
	public void inserirCliente(Cliente cliente) throws Exception{

		try {
			cn = DaoFactory.abrirConexao();
			stmt = cn.prepareStatement("INSERT INTO CLIENTES (NOME, EMAIL) VALUES (?,?)", Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, cliente.getNome()); 
			stmt.setString(2, cliente.getEmail());
			stmt.execute();
			
			rs = stmt.getGeneratedKeys();
			while (rs.next()){
				cliente.setId(rs.getInt(1));
			}
		} catch (Exception e) { 
			throw e;
		} finally { 
			cn.close();
			if (stmt != null) stmt.close();
		} 
	}
	

	@Override
	public Cliente buscarCliente(int id) throws Exception{ 

		Cliente cliente = null;
		List<Pedido> pedidos = new ArrayList<>();

		try {
			cn=DaoFactory.abrirConexao();
			String sql="SELECT IDPEDIDO,DATA,DESCRICAO,VALOR FROM PEDIDOS WHERE IDCLIENTE=?";
			stmt = cn.prepareStatement(sql);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			while (rs.next()){
				pedidos.add(new Pedido(rs.getDate("DATA"),rs.getString("DESCRICAO"), rs.getDouble("VALOR"),
						rs.getInt("IDPEDIDO"), id));
			}

			sql="SELECT NOME,EMAIL FROM CLIENTES WHERE IDCLIENTE=?";
			stmt = cn.prepareStatement(sql);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()){
				cliente = new Cliente(rs.getString("NOME"), rs.getString("EMAIL"), pedidos);
			}

		} catch (Exception e) {
			throw e;
		}
		finally{
			cn.close();
			if (stmt != null) stmt.close();
			if (rs != null) rs.close();
		}

		return cliente;

	} 

}