package br.com.fiap.dao;

import java.util.List;

import br.com.fiap.entity.Pedido;

public interface PedidoDAO {
	public void inserirPedido(Pedido pedido) throws Exception;
	public List<Pedido> listarPedidos(int idCliente) throws Exception;
}
